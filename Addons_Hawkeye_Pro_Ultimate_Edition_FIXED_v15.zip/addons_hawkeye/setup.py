from setuptools import setup, find_packages

setup(
    name="addons_hawkeye",
    version="0.1.0",
    description="Addons Hawkeye Pro – Executive Sales Command Center for ERPNext v15",
    author="Rajeev C.P., ADDON-S LLC",
    author_email="info@addon-s.com",
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
)
