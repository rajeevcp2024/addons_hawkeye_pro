app_name = "addons_hawkeye"
app_title = "Addons Hawkeye Pro"
app_publisher = "Rajeev C.P., ADDON-S LLC"
app_description = "Executive Sales Command Center with Smart Blinking Alerts for ERPNext v15"
app_icon = "octicon octicon-eye"
app_color = "#111827"
app_email = "info@addon-s.com"
app_license = "MIT"

# Include assets in Desk
app_include_css = "/assets/addons_hawkeye/css/alerts.css"
app_include_js = "/assets/addons_hawkeye/js/hawkeye_alert_panel.js"

# Exported fixtures (installed automatically)
fixtures = [
    {"dt": "Custom Field", "filters": [["name", "like", "Lead-ahp_%"]]},
    {"dt": "Hawkeye Alert"},
]

# Doc event triggers
doc_events = {
    "Lead": {"after_insert": "addons_hawkeye.alerts.new_lead_alert"},
    "Quotation": {"on_submit": "addons_hawkeye.alerts.quotation_submitted"},
    "Sales Invoice": {"on_submit": "addons_hawkeye.alerts.invoice_submitted"},
    "Payment Entry": {"on_submit": "addons_hawkeye.alerts.payment_received"},
}

# Scheduler to send meeting reminders (requires Email Account configured to Outlook/O365)
scheduler_events = {
    "cron": {
        "*/5 * * * *": [
            "addons_hawkeye.alerts.meeting_reminder_job",
        ]
    }
}
