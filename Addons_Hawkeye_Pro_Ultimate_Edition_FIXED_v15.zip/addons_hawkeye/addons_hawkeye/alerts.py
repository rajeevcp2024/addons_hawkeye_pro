\
import frappe
from frappe.utils import now_datetime

ALERTS = [
    ("New Lead Received", "red"),
    ("Quotation Sent", "green"),
    ("Agreement Pending", "red"),
    ("Invoice Pending", "yellow"),
    ("Payment Received", "green"),
    ("Send Receipt", "yellow"),
]

def ensure_seed_alerts():
    # create rows if missing
    for title, color in ALERTS:
        if not frappe.db.exists("Hawkeye Alert", title):
            doc = frappe.get_doc({
                "doctype": "Hawkeye Alert",
                "alert_name": title,
                "color": color,
                "active": 0,
            })
            doc.insert(ignore_permissions=True)

def set_alert(title: str, active: int, color: str | None = None):
    ensure_seed_alerts()
    name = frappe.db.get_value("Hawkeye Alert", {"alert_name": title}, "name")
    if not name:
        return
    frappe.db.set_value("Hawkeye Alert", name, "active", active)
    if color:
        frappe.db.set_value("Hawkeye Alert", name, "color", color)
    frappe.db.commit()
    # notify open desks to refresh panel
    frappe.publish_realtime("hawkeye_alert_refresh", {})

def new_lead_alert(doc, method=None):
    set_alert("New Lead Received", 1, "red")

def quotation_submitted(doc, method=None):
    set_alert("Quotation Sent", 1, "green")
    set_alert("Invoice Pending", 1, "yellow")
    # Agreement pending can be enabled based on your flow
    set_alert("Agreement Pending", 1, "red")

def invoice_submitted(doc, method=None):
    set_alert("Invoice Pending", 0)
    set_alert("Send Receipt", 1, "yellow")

def payment_received(doc, method=None):
    set_alert("Payment Received", 1, "green")
    set_alert("Send Receipt", 0)

def meeting_reminder_job():
    # Sends reminders for meetings starting within 60 minutes
    # Uses ERPNext Email Account configuration (Outlook/O365 SMTP).
    now = now_datetime()
    upcoming = frappe.get_all(
        "Event",
        fields=["name", "subject", "starts_on", "description"],
        filters={"starts_on": (">=", now)},
        order_by="starts_on asc",
        limit=20,
    )
    for e in upcoming:
        if not e.starts_on:
            continue
        delta = (e.starts_on - now).total_seconds()
        if 0 <= delta <= 3600:
            # real-time pop-up
            frappe.publish_realtime("hawkeye_meeting_alert", {"subject": e.subject, "starts_on": str(e.starts_on)})
            # optional email notification to Event owner
            try:
                owner = frappe.db.get_value("Event", e.name, "owner")
                if owner:
                    user_email = frappe.db.get_value("User", owner, "email")
                    if user_email:
                        frappe.sendmail(
                            recipients=[user_email],
                            subject=f"Meeting Reminder: {e.subject}",
                            message=f"Your meeting starts at {e.starts_on}.\\n\\n{e.description or ''}",
                        )
            except Exception:
                # don't break scheduler
                frappe.log_error(frappe.get_traceback(), "Hawkeye meeting reminder failed")
