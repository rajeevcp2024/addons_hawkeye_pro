\
(function () {
  function renderPanel(alerts) {
    const wrapId = "ahp-alert-panel";
    let panel = document.getElementById(wrapId);
    if (!panel) {
      panel = document.createElement("div");
      panel.id = wrapId;
      panel.style.padding = "10px 16px";
      panel.style.margin = "10px 0";
      panel.style.borderRadius = "14px";
      panel.style.background = "linear-gradient(135deg, rgba(17,24,39,.92), rgba(2,6,23,.92))";
      panel.style.border = "1px solid rgba(255,255,255,.10)";
      panel.style.color = "#fff";
      panel.style.boxShadow = "0 12px 30px rgba(0,0,0,.35)";

      const title = document.createElement("div");
      title.className = "ahp-panel-title";
      title.innerText = "Addons Hawkeye Pro – Live Alerts";
      panel.appendChild(title);

      const wrap = document.createElement("div");
      wrap.className = "ahp-alert-wrap";
      wrap.id = "ahp-alert-wrap";
      panel.appendChild(wrap);

      // Insert panel at top of Desk (works on v15 desk routes)
      const desk = document.querySelector(".desk-page") || document.body;
      desk.prepend(panel);
    }

    const wrap = document.getElementById("ahp-alert-wrap");
    if (!wrap) return;
    wrap.innerHTML = "";

    alerts.forEach(a => {
      if (!a.active) return;
      const btn = document.createElement("div");
      const colorClass = a.color === "green" ? "ahp-green" : (a.color === "yellow" ? "ahp-yellow" : "ahp-red");
      btn.className = `ahp-led ${colorClass} ahp-blink`;
      btn.innerHTML = `<span>●</span><span>${a.alert_name}</span>`;
      btn.onclick = () => {
        // Ack: stop blinking for the current user by disabling alert (simple global ack)
        frappe.call("addons_hawkeye.api.ack_alert", { alert_name: a.alert_name }).then(() => refresh());
      };
      wrap.appendChild(btn);
    });

    if (!wrap.children.length) {
      const empty = document.createElement("div");
      empty.style.opacity = ".85";
      empty.style.padding = "8px 0";
      empty.innerText = "All clear. No pending actions.";
      wrap.appendChild(empty);
    }
  }

  function refresh() {
    if (!window.frappe) return;
    frappe.call("addons_hawkeye.api.get_active_alerts").then(r => {
      renderPanel((r.message || []));
    });
  }

  frappe.ready(() => {
    refresh();
    frappe.realtime.on("hawkeye_alert_refresh", refresh);
    frappe.realtime.on("hawkeye_meeting_alert", (data) => {
      frappe.msgprint({
        title: "Upcoming Meeting",
        message: `${data.subject} at ${data.starts_on}`,
        indicator: "orange"
      });
    });
  });
})();
