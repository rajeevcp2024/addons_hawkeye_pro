import frappe

@frappe.whitelist()
def get_active_alerts():
    return frappe.get_all(
        "Hawkeye Alert",
        fields=["alert_name", "active", "color"],
        order_by="modified desc",
        limit=50,
    )

@frappe.whitelist()
def ack_alert(alert_name: str):
    # Simple global acknowledgement: turn off the alert
    name = frappe.db.get_value("Hawkeye Alert", {"alert_name": alert_name}, "name")
    if name:
        frappe.db.set_value("Hawkeye Alert", name, "active", 0)
        frappe.db.commit()
        frappe.publish_realtime("hawkeye_alert_refresh", {})
    return True
