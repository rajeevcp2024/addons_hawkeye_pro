# Addons Hawkeye Pro – Ultimate Edition
Developed by Rajeev C.P., Senior Account Manager – ADDON-S LLC

Executive Sales Command Center for ERPNext v15:
- CEO View KPIs and charts (Workspace)
- Meeting Scheduler shortcut
- Smart Blinking Alerts (New Lead, Quotation Sent, Invoice Pending, Agreement Pending, Payment Received, Send Receipt)

## Install (bench)
bench get-app <repo_url>
bench --site <site> install-app addons_hawkeye
bench --site <site> migrate
